from crewai_tools import YoutubeChannelSearchTool

#Initialize the tool with a specific youtube channel handle to target your search

yt_tool=YoutubeChannelSearchTool(Youtube_channel_handler="@krishnaik06")